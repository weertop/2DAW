package controlador;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Archivo;
import modelo.Opinion;

/**
 * Servlet implementation class aniadirForo
 */
@WebServlet("/aniadirForo")
public class aniadirForo extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html; charset=UTF-8");
		
		ServletContext contexto = request.getServletContext();
		
		String ruta = "\\WebContent\\foro.txt";
		String pathRelativo = contexto.getContextPath();			
		String pathDevuelto = contexto.getRealPath(pathRelativo);
		
		String pathReal = pathDevuelto.substring(0,pathDevuelto.indexOf('.')) + pathRelativo.substring(1) + ruta;
		
		Archivo a = new Archivo(pathReal);
		
		String nombre = request.getParameter("nombre").trim();
		
		String[] identificas = request.getParameterValues("identificas");
		String identificasJunto ="";
		for(int i=0; i< identificas.length; i++) {
			if(i == identificas.length-1) {
				identificasJunto+=identificas[i];
				break;
			}
			identificasJunto += identificas[i] + ',';
		}

		String comentario =  request.getParameter("comentario");
		
		String fechaHora = request.getParameter("fecha");
		
		Opinion o = new Opinion(nombre, identificasJunto, comentario, fechaHora);
		
		a.add(o.generaOpnion());				//lo aniadimos al foro.txt
		
		//Volvemos al index asi el usuario no nota que se ejecuta el servlet
		
		response.sendRedirect("index.jsp");
	}

}
