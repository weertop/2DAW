package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Abmc;
import modelo.Palabra;

/**
 * Servlet implementation class controlaAccion
 */
@WebServlet("/controlaAccion")
public class controlaAccion extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int action = Integer.parseInt(request.getParameter("action"));
		
		try {
			switch(action) {
			case 1:
				mostrar(request,response,action);
	 			break;
			case 2:
				mostrar(request,response,action);
				break;
			case 3:
				String palabraNueva = request.getParameter("palabra").trim();
				if(palabraNueva!=null && !palabraNueva.equals("")) {
					String[] soloUno = palabraNueva.split(" ");
					Palabra palabra = new Palabra(soloUno[0],1);
					aniadir(request,response,palabra);
				}
				break;
			case 4:
				String rec = request.getParameter("voto");
				String[] palabraVoto = rec.split(":");
				votar(request,response,Integer.parseInt(palabraVoto[0]),Integer.parseInt(palabraVoto[1]));
				break;
			}
		}catch(SQLException ex) {
			 System.out.println("Fallo en la SQL");
			ex.printStackTrace();
		 }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private void mostrar(HttpServletRequest request, HttpServletResponse response, int action) throws ServletException, IOException, SQLException{ 
		Abmc abmc = new Abmc();
		ArrayList<Palabra> listaPalabras = abmc.consultarTodo();
		request.setAttribute("miListaPalabras", listaPalabras);
		
		if(action==1) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/despliegaPalabras.jsp");
			dispatcher.forward(request,response);
		}else{
			RequestDispatcher dispatcher = request.getRequestDispatcher("/votarPalabra.jsp");
			dispatcher.forward(request,response);
		}
		
	}
	
	private void aniadir(HttpServletRequest request, HttpServletResponse response, Palabra palabra) throws ServletException, IOException, SQLException{ 
				
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		Abmc abmc = new Abmc();
		int existe = abmc.comprobarExiste(palabra);
		int isInsert;
				
		if(existe==0) {
			isInsert = abmc.insertar(palabra);
			
			request.setAttribute("isCorrect", String.valueOf(isInsert));										//TODO faltaria envairlo a una pagina donde se diga correcto eliminado, luego un enlace para volver a mostrar los usuarios dependiendo del tipo de usuario
			RequestDispatcher dispatcher = request.getRequestDispatcher("/despliegaComprobacion.jsp");
			dispatcher.forward(request,response);
			request.setCharacterEncoding("UTF-8");					//ojo a esto se debe especificar el formato UTF-8 para que no de problemas
			
		}else {
			out.println("<h1>Ya existe esa palabra en la BD</h1>");
			out.println("<p><a href=\"aniadirPalabra.jsp\">A�adir otra palabra</a></p>");
			out.println("<p><a href=\"index.jsp\">Volver index</a></p>");
		}
	}
	
	private void votar(HttpServletRequest request, HttpServletResponse response, int id, int votos) throws ServletException, IOException, SQLException{ 
		Abmc abmc = new Abmc();
		int isModified = abmc.votar(id,votos);
		
		request.setAttribute("isCorrect", String.valueOf(isModified));										//TODO faltaria envairlo a una pagina donde se diga correcto eliminado, luego un enlace para volver a mostrar los usuarios dependiendo del tipo de usuario
		RequestDispatcher dispatcher = request.getRequestDispatcher("/despliegaComprobacion.jsp");
		dispatcher.forward(request,response);
	}

}
