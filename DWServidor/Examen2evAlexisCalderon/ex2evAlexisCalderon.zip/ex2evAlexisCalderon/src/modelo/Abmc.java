package modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Abmc {

	public ArrayList<Palabra> consultarTodo() {
		ArrayList<Palabra> listaPalabras = new ArrayList<Palabra>();
		Connection con = null;
		Statement sentencia =null;
		String query = "select * from palabras order by 3 desc";
		ResultSet resultado = null;										//recibe una lisa de resultados
		try {
			con = Conexion.conectar();
			sentencia = con.createStatement();
			resultado = sentencia.executeQuery(query);
			while(resultado.next()) {
				Palabra miPalabra = new Palabra();
				miPalabra.setId(resultado.getInt(1));
				miPalabra.setPalabra(resultado.getString(2));
				miPalabra.setVoto(resultado.getInt(3));
				listaPalabras.add(miPalabra);
			}
			
			resultado.close();
			con.close();
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		return listaPalabras;
	}
	
	public int comprobarExiste(Palabra p) {
		int existe = -1;
		Connection con = null;
		Statement sentencia =null;
		String query = "select count(*) from palabras where palabra='"+ p.getPalabra() +"';";
		System.out.println("busqueda--->" + query);
		ResultSet resultado = null;										//recibe una lisa de resultados
		try {
			con = Conexion.conectar();
			sentencia = con.createStatement();
			resultado = sentencia.executeQuery(query);
			while(resultado.next()) {
				existe = resultado.getInt(1);
			}
			
			resultado.close();
			con.close();
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		System.out.println("comprobar existe--->" + existe);
		return existe;
	}
	
	public int insertar(Palabra p) {
		Statement sentencia = null;
		Connection con = null;
		int isInserted = 0;
																									//ojo que voto no lleva comilla simple
		String query="insert into palabras values(NULL,'"+p.getPalabra()+"',"+p.getVoto()+");";
		System.out.println(query);
		try {
			con = Conexion.conectar();
			sentencia = con.createStatement();
			isInserted = sentencia.executeUpdate(query);
			
			sentencia.close();
			con.close();
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		//return 0;
		return isInserted;
	}
	
	public int votar(int id, int votos) {
		
		Statement sentencia = null;
		Connection con = null;
		int isModified = 0;
		votos++;										
		String query="update palabras set votos = '" + votos + "' where id="+ id +";";
		
		try {
			con = Conexion.conectar();
			sentencia = con.createStatement();
			isModified = sentencia.executeUpdate(query);
			
			sentencia.close();
			con.close();
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		return isModified;
		
	}
	
}
