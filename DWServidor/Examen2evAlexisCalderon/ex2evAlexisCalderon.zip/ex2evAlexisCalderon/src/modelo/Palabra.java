package modelo;

public class Palabra {
	private int id;
	private String palabra;
	private int voto;
	
	public Palabra() {
		
	}
	
	public Palabra(String palabra, int voto) {
		this.palabra = palabra;
		this.voto = voto;
	}
	
	public Palabra(int id, String palabra, int voto) {
		super();
		this.id = id;
		this.palabra = palabra;
		this.voto = voto;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPalabra() {
		return palabra;
	}

	public void setPalabra(String palabra) {
		this.palabra = palabra;
	}

	public int getVoto() {
		return voto;
	}

	public void setVoto(int voto) {
		this.voto = voto;
	}

	@Override
	public String toString() {
		return "Palabra [id=" + id + ", palabra=" + palabra + ", voto=" + voto + "]";
	}
	
	
}
