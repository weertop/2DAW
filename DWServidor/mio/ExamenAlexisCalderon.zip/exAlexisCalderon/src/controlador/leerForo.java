package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Archivo;

/**
 * Servlet implementation class leerForo
 */
@WebServlet("/leerForo")
public class leerForo extends HttpServlet {
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html; charset=UTF-8");
		
		ServletContext contexto = request.getServletContext();

		String ruta = "\\WebContent\\foro.txt";
		String pathRelativo = contexto.getContextPath();			
		String pathDevuelto = contexto.getRealPath(pathRelativo);
		String pathReal = pathDevuelto.substring(0,pathDevuelto.indexOf('.')) + pathRelativo.substring(1) + ruta;
		
		Archivo a = new Archivo(pathReal);
		
		//cargamos la lista en un arraylist
		ArrayList<String> lista = a.leerArchivo();
		
		//limpiamos las aficiones y las guardamos en un array
		String[] listaIdentificas = null;
		String[] listaIdentificasSeparado = null;
		
		for(String b:lista){					
			listaIdentificas = b.split(":");
		}
		
		for(int j=2;j<listaIdentificas.length;j+=4) {
			listaIdentificasSeparado = listaIdentificas[j].split(",");
		}
		
		String realizar = request.getParameter("quiero");				//vemos que envia el usuario lo que quiere hacer
		
		if(realizar.equals("opiniones")) {
			try {
				out.println("<!DOCTYPE html><html><head><h1>Opiniones</h1></head><body>");
				out.println("<table border=\"2\">");
				for(int i=lista.size()-1; i>0 ;i--){	
					out.println("<tr>");
					out.println("<td>" + lista.get(i).toString() + "</td>");
					out.println("</tr>");
				}
				out.println("</table>");
				out.println("<p><a href=\"index.jsp\">Volver inicio</a></p>");
				out.println("</body></html>");
			}finally{
				out.close();
			}
		}
		if(realizar.equals("estadisticas")) {
			try {
				out.println("<!DOCTYPE html><html><head><h1>Estadisticas</h1></head><body>");
				out.println("<table border=\"2\">");
				for(int i=0; i<listaIdentificasSeparado.length ;i++){
					out.println("<tr>");
					out.println("<td>" + listaIdentificasSeparado[i] + "</td>");
					out.println("</tr>");
				}
				out.println("</table>");
				out.println("<p><a href=\"index.jsp\">Volver inicio</a></p>");
				out.println("</body></html>");
			}finally{
				out.close();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}

}
