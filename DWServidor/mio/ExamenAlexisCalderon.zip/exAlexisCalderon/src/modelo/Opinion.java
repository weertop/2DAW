package modelo;

public class Opinion {
	
	private String fechaHora;
	private String nombre;
	private String identificas;
	private String comentario;
	
	public Opinion(String nombre, String identificas, String comentario, String fechaHora) {
		super();
		this.nombre = nombre;
		this.identificas = identificas;
		this.comentario = comentario;
		this.fechaHora = fechaHora;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getIdentificas() {
		return identificas;
	}

	public void setIdentificas(String identificas) {
		this.identificas = identificas;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	
	public String getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(String fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String generaOpnion() {
		
		return this.fechaHora + ":" + this.nombre + ":" + this.identificas + ":" + this.comentario;
	}
	
	@Override
	public String toString() {
		return "Opinion [nombre=" + nombre + ", identificas=" + identificas + ", comentario=" + comentario + "]";
	}
	
	
}
